# SELVE

> A sacred text for the nervous system  
> Created by Christian Nortone (https://soundcloud.com/nortone)  
> Repo prepared for `ruudriot` via GitHub transfer

## Deploy

You can deploy this directly to [vercel.com](https://vercel.com)  
Drag-and-drop or connect via GitHub.

- Includes `index.html` with intro audio + enter screen
- PWA-ready `manifest.json`
- Routing config via `vercel.json`